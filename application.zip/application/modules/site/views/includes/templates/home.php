<!DOCTYPE html>
<html lang="en">
	<?php echo $this->load->view('includes/header', '', TRUE);?>
    <body class="home">
        <?php echo $content; ?>
	</body>
</html>