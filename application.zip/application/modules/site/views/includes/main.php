   <div class="main" role="main">
        <div id="content" class="content full">
            <div class="container">
            	<?php //echo $this->load->view('home/events', '', TRUE);?>
                
                <hr class="fw">
                <?php echo $this->load->view('home/blog', '', TRUE);?>
            </div>
        </div>
    </div>