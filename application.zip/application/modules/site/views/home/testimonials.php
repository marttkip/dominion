
        <!-- PANEL 6 -->
        <div class="pm-column-container testimonials pm-parallax-panel" style="background-color:#20bac7; background-image:url(<?php echo base_url().'assets/themes/medicallink/'?>img/home/testimonials-bg.jpg); background-repeat:repeat-y;" data-stellar-background-ratio="0.5" data-stellar-vertical-offset="0">
        	
            <div class="container pm-containerPadding100">
            	<div class="row">
                
                	<div class="col-lg-12 pm-center">
                    	<h5 class="light">What patients are saying about Medical-Link</h5>
                    </div>
                                
                	<div class="pm-testimonials-carousel" id="pm-testimonials-carousel">
                    
                    	<ul class="pm-testimonial-items">
                        	<li>
                                <div class="pm-testimonial-img" style="background-image:url(<?php echo base_url().'assets/themes/medicallink/'?>img/home/testimonial-1.jpg);">
                                	<div class="pm-testimonial-img-icon">
                                    	<img src="<?php echo base_url().'assets/themes/medicallink/'?>img/home/post-icon.jpg" class="img-responsive pm-center-align" alt="icon">
                                    </div>
                                </div>
                                <p class="pm-testimonial-name">christine blaine</p>
                                <p class="pm-testimonial-title">Graphic Artist</p>
                                <div class="pm-testimonial-divider"></div>
                                <p class="pm-testimonial-quote">Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim ad minim veniam quis nostrud exerci tation.</p>
                            </li>
                            <li>                                
                                <div class="pm-testimonial-img" style="background-image:url(<?php echo base_url().'assets/themes/medicallink/'?>img/home/testimonial-2.jpg);">
                                	<div class="pm-testimonial-img-icon">
                                    	<img src="<?php echo base_url().'assets/themes/medicallink/'?>img/home/post-icon.jpg" class="img-responsive pm-center-align" alt="icon">
                                    </div>
                                </div>
                                <p class="pm-testimonial-name">dave johnson</p>
                                <p class="pm-testimonial-title">HR Specialist</p>
                                <div class="pm-testimonial-divider"></div>
                                <p class="pm-testimonial-quote">Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim ad minim veniam quis nostrud exerci tation.</p>
                            </li>
                            <li>
                                <div class="pm-testimonial-img" style="background-image:url(<?php echo base_url().'assets/themes/medicallink/'?>img/home/testimonial-3.jpg);">
                                	<div class="pm-testimonial-img-icon">
                                    	<img src="<?php echo base_url().'assets/themes/medicallink/'?>img/home/post-icon.jpg" class="img-responsive pm-center-align" alt="icon">
                                    </div>
                                </div>
                                <p class="pm-testimonial-name">Michael smith</p>
                                <p class="pm-testimonial-title">Mechanical Engineer</p>
                                <div class="pm-testimonial-divider"></div>
                                <p class="pm-testimonial-quote">Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim ad minim veniam quis nostrud exerci tation.</p>
                            </li>
                        </ul>
                    
                    </div>
                
                </div>
            </div>
            
        </div>
        <!-- PANEL 6 end -->
        