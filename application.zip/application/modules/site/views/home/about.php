<!-- Lead Content -->
    <div class="lead-content clearfix">
        <div class="lead-content-wrapper">
                <div class="header-title">
                     <h2 style="margin:0 auto; text-align:center;">JOIN A GROUP</h2>
                </div>
               
            <div class="container">
                <div class="row">
                    <div class="col-md-4 col-sm-4 featured-block">
                        <h3>DG Junior</h3>
                        <figure>
                            <a href="#"><img src="<?php echo site_url();?>assets/images/junior.jpeg" alt="Our Community"></a>
                        </figure>
                        <p>DG Juniors seeks to empower primary school children with life skills that helps them to grow in the light of being independent people and also having a vision in life </p>
                    </div>
                    
                    <div class="col-md-4 col-sm-4 featured-block">
                        <h3>DG Young Professionals</h3>
                        <figure>
                            <a href="#"><img src="<?php echo site_url();?>assets/images/young.jpg" alt="Our Community"></a>
                        </figure>
                        <p>DG Young Profesionals seeks to empower college and university student build up carrers that can help them in life and also understanding the needs in business industries around.  </p>
                    </div>
                  
                    <div class="col-md-4 col-sm-4 featured-block">
                        <h3>DG Seniors</h3>
                        <figure>
                            <a href="#"><img src="<?php echo site_url();?>assets/themes/adore/images/img_join.jpg" alt="Our Community"></a>
                        </figure>
                        <p>DG Seniors seeks to empower secondary school student through mentorship programs in identifying a purpose in life and also looking out to growth in terms of ideas to make better adults in life .</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Start Body Content -->