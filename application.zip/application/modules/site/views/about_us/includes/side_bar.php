<div id="sidebar">             
    <aside class="widget-container">
        <div class="widget-wrapper clearfix">
            <h3 class="widget-title">GET IN TOUCH</h3>
                <article class="text-widget ">
                  
                    <ul>
                 
                        <li><strong>Address:</strong>Haile selasse Road , Opp Thika School for the blind, P.O Box 2201 Thika 01000</li>
                        <li><strong>Email:</strong> info@uzuriinstitute.ac.ke</li>
                        <li><strong>Phone:</strong> 0723 560 867/0700 455 435</li>
                    </ul>   
         <iframe class="map-area" src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3988.827930758751!2d36.81798031432537!3d-1.2766536359747769!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x182f172bf2fc9c5b%3A0x9c1b2815f7c0853a!2sUzuri+Institute+of+Technology+and+Development!5e0!3m2!1sen!2ske!4v1455261085905"  frameborder="0" style="border:0" allowfullscreen></iframe>
                </article>
                <a href="<?php echo site_url();?>contact-us" class="button-more">More About Us</a>

        </div>
    </aside>
    <aside class="widget-container">
        <div class="widget-wrapper clearfix">
            <h3 class="widget-title">Testimonial</h3>
            <article class="text-widget">
                <img src="http://placehold.it/96x96" data-retina="http://placehold.it/192x192" alt="Jane Cross" class="imgframe alignleft testimonial" />               
                <div class="testimonial-header">
                    <h4>Jane Cross</h4>
                    <h5>Management Economy Student</h5>
                </div>
                <blockquote><p>Cras pharetra hendrerit mollis. Suspendisse aliquet in metus nec sollicitudin. Interdum et malesuada fames ac ante ipsum primis in faucibus. Integer tellus elit, cursus quis ante eget, molestie euismod tellus. Vestibulum ultricies neque urna, in adipiscing enim aliquet sit amet. Vivamus ullamcorper, diam id pharetra venenatis, erat risus euismod dui, sit amet ullamcorper libero est consequat libero. Ut augue nisl, varius et cursus in, faucibus at neque.</p>
                </blockquote>
            </article>
            <a href="#" class="button-more">Testimonial</a>
        </div>
    </aside>
</div>